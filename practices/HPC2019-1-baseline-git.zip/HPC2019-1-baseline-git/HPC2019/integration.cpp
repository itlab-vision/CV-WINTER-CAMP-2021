#include "main_header.h"


void Func(dcomplex * iH, dcomplex * y, dcomplex * res, unsigned int size_system)
{
	matrix_mult(iH, y, res, size_system);
}

void stepRK4(dcomplex * y, dcomplex * y1, dcomplex * y2, dcomplex * y3, dcomplex * y4,
	dcomplex * yTmp1, dcomplex * yTmp2, dcomplex * iH, double h, unsigned int size_system)
{
	unsigned int size_system2 = size_system * size_system;
	Func(iH, y, yTmp1, size_system);
	for (int i = 0; i < size_system2; i++)
	{
		y1[i] = h * yTmp1[i];
		yTmp2[i] = (y[i] + y1[i]) / 2.0;
	}
	Func(iH, yTmp2, yTmp1, size_system);
	for (int i = 0; i < size_system2; i++)
	{
		y2[i] = h * yTmp1[i];
		yTmp2[i] = (y[i] + y2[i]) / 2.0;
	}
	Func(iH, yTmp2, yTmp1, size_system);
	for (int i = 0; i < size_system2; i++)
	{
		y3[i] = h * yTmp1[i];
		yTmp2[i] = (y[i] + y3[i]);
	}
	Func(iH, yTmp2, yTmp1, size_system);
	for (int i = 0; i < size_system2; i++)
	{
		y4[i] = h * yTmp1[i];
		y[i] += (y1[i] + 2.0 * y2[i] + 2.0 * y3[i] + y4[i]) / 6.0;
	}
}

void RK4(dcomplex * iH, dcomplex * y0, double h, unsigned int steps, unsigned int size)
{
	dcomplex * y1 = new dcomplex[size*size];
	dcomplex * y2 = new dcomplex[size*size];
	dcomplex * y3 = new dcomplex[size*size];
	dcomplex * y4 = new dcomplex[size*size];
	dcomplex * yTmp1 = new dcomplex[size*size];
	dcomplex * yTmp2 = new dcomplex[size*size];
	for (int i = 0; i < steps; i++)
	{
		stepRK4(y0, y1, y2, y3, y4, yTmp1, yTmp2, iH, h, size);
	}

	delete(y1);
	delete(y2);
	delete(y3);
	delete(y4);
	delete(yTmp1);
	delete(yTmp2);
}
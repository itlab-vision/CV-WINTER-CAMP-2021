#include <algorithm>
#include <string>
#include "main_header.h"


void matrix_mult_noblock(dcomplex * a, dcomplex * b, dcomplex * res, unsigned int size)
{
	memset(res, 0, size*size * sizeof(dcomplex));
//#pragma omp parallel for
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
//#pragma omp simd
			for (int k = 0; k < size; k++)
			{
				res[i*size + j] += a[i*size + k] * b[k*size + j];
			}
		}
	}
}

void matrix_mult(dcomplex * a, dcomplex * b, dcomplex * res, unsigned int size)
{
	matrix_mult_noblock(a, b, res, size);
}